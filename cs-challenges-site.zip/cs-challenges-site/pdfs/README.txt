Place your challenge PDFs in this folder and update their paths in data/challenges.json.

Examples:
- pdfs/2025-09-curious-sequence.pdf
- pdfs/2025-10-dice-paradox.pdf
- pdfs/2025-11-collatz-path.pdf

Tip: Filenames with year-month help sorting and linking.
